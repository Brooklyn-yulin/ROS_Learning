#!/usr/bin/env python3
#coding=utf-8

import rospy
from std_msgs.msg import String

def xu_callback(msg):
    rospy.loginfo(msg.data)

def zhang_callback(msg):
    rospy.logwarn(msg.data)

def huang_node():
    rospy.init_node("huang_node")

    sub = rospy.Subscriber("qu_jian_shen", String, xu_callback, queue_size=10)
    sub_2 = rospy.Subscriber("jiu_shi_qu_jian_shen", String, zhang_callback, queue_size=10)
    rospy.spin()

if __name__ == "__main__":
    huang_node()