#!/usr/bin/env python3
#coding=utf-8

import rospy
from std_msgs.msg import String

def xu_node():
    rospy.init_node("xu_node")
    rospy.loginfo("初始化成功")

    pub = rospy.Publisher("qu_jian_shen", String, queue_size=10)
    rate=rospy.Rate(10)

    while not rospy.is_shutdown():
        rospy.loginfo("开始发布消息")
        msg=String()
        msg.data="去健身"
        pub.publish(msg)
        rate.sleep()

if __name__ =="__main__":
    try:
        xu_node()
    except rospy.ROSInterruptException:
        pass


    
