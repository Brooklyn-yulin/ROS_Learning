#!/usr/bin/env python3
#coding=utf-8

import rospy
from std_msgs.msg import String

def zhang_node():
    rospy.init_node("xu_node")
    rospy.loginfo("初始化成功")

    pub = rospy.Publisher("jiu_shi_qu_jian_shen", String, queue_size=10)
    rate=rospy.Rate(10)

    while not rospy.is_shutdown():
        rospy.loginfo("开始发布消息")
        msg=String()
        msg.data="我也去"
        pub.publish(msg)
        rate.sleep()

if __name__ =="__main__":
    try:
        zhang_node()
    except rospy.ROSInterruptException:
        pass


    
