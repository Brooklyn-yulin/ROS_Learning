#! /usr/bin/env python
# encoding=utf-8

import rospy, sys
import moveit_commander
from moveit_msgs.msg import RobotTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint

from geometry_msgs.msg import PoseStamped, Pose
from tf.transformations import euler_from_quaternion, quaternion_from_euler

class MoveItIkDemo:
    def __init__(self):
        # 初始化move_group的API
        moveit_commander.roscpp_initialize(sys.argv)

        # 初始化ROS节点
        rospy.init_node('moveit_ik_demo')

        # 初始化需要使用move_group控制的机械臂中的arm group
        arm = moveit_commander.MoveGroupCommander('Manipulator')

        # 获取终端link的名称
        end_effector_link = arm.get_end_effector_link()

        # 设置目标位置所使用的参考坐标系
        reference_frame = 'world'
        arm.set_pose_reference_frame(reference_frame)

        # 但运动规划失败后允许重新规划，通常情况下逆运动学求解会出现多解或者无解，导致规划失败，打开重新规划后，可以尝试求解五次
        arm.allow_replanning(True)

        # 设置位置（单位：米）和姿态（单位：弧度）的允许误差值
        arm.set_goal_position_tolerance(0.01)
        arm.set_goal_orientation_tolerance(0.05)

        # 控制机械臂先回到初始化位置
        arm.set_named_target('pack')
        arm.go()
        rospy.sleep(2)

        # 设置机械臂工作空间中的目标位姿，位置使用x、y、z坐标描述
        # 姿态使用四元数描述，基于base_link坐标系
        target_pose = PoseStamped() # 使用PoseStamped消息数据描述机器人的目标位姿
        target_pose.header.frame_id = reference_frame
        target_pose.header.stamp = rospy.Time.now() # 创建时间戳
        target_pose.pose.position.x = 0.191995
        target_pose.pose.position.y = 0.213868
        target_pose.pose.position.z = 0.520436
        target_pose.pose.orientation.x = 0.911822
        target_pose.pose.orientation.y = -0.0269758
        target_pose.pose.orientation.z = 0.285694
        target_pose.pose.orientation.w = -0.293653

        # 设置机械臂当前的状态作为运动初始状态
        arm.set_start_state_to_current_state()

        # 设置机械臂终端运动的目标位姿
        arm.set_pose_target(target_pose, end_effector_link)

        # 规划运动路径
        traj = arm.plan()

        # 按照规划的运动路径控制机械臂运动
        arm.execute(traj)
        rospy.sleep


        # 控制机械臂终端向右移动5cm
        # shift_pose_target有三个参数，第一个参数用于描述机器人需要在哪个轴向上进行运动：0、1、2、3、4、5分别对应与x、y、z、roll、pitch、yaw
        # 第二个参数用于描述运动尺度，如果是平移运动则单位为米；如果是旋转运动，则单位是弧度
        # 第三个参数用于描述运动的对象，即末端link
        #arm.shift_pose_target(1, -0.05, end_effector_link) 
        #arm.go()
        #rospy.sleep(1)

        # 控制机械臂终端反转90度
        #arm.shift_pose_target(3, -1.57, end_effector_link)
        #arm.go()
        #rospy.sleep(1) 

        # 控制机械臂回到初始化位置
        arm.set_named_target('pack')
        arm.go()

        # 关闭并退出moveit
        moveit_commander.roscpp_shutdown
        moveit_commander.os._exit(0) 

if __name__ == "__main__":
    MoveItIkDemo()      
